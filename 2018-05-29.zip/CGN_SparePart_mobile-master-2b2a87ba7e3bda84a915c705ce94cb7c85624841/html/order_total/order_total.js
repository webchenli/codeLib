function closeWin (){
	summer.closeWin()
}
function nofind(_this,type){  
    src = "../static/mall/images/default_small.png"
    _this.src = src
    _this.onerror=null;
}
summerready = function(){
	
}